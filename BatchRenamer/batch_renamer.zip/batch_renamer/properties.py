"""Property groups for Batch Renamer addon UI state."""

import bpy
from bpy.props import StringProperty, BoolProperty, EnumProperty, IntProperty
from bpy.types import PropertyGroup


class BATCHRENAME_PG_settings(PropertyGroup):
    """Main settings property group for the Batch Renamer addon."""
    
    # Data sync options
    sync_suffix: StringProperty(
        name="Data Suffix",
        description="Optional suffix to add to data-block names (e.g., '_mesh')",
        default=""
    )
    
    # Batch rename options
    find_string: StringProperty(
        name="Find",
        description="Text to search for in names",
        default=""
    )
    replace_string: StringProperty(
        name="Replace",
        description="Text to replace with",
        default=""
    )
    prefix_string: StringProperty(
        name="Prefix",
        description="Prefix to add to names",
        default=""
    )
    suffix_string: StringProperty(
        name="Suffix",
        description="Suffix to add to names",
        default=""
    )
    
    # Sequential numbering
    base_name: StringProperty(
        name="Base Name",
        description="Base name for sequential renaming",
        default="Object"
    )
    start_number: IntProperty(
        name="Start",
        description="Starting number for sequence",
        default=1,
        min=0
    )
    zero_padding: IntProperty(
        name="Padding",
        description="Number of digits (zero-padded)",
        default=3,
        min=1,
        max=6
    )
    
    # Case conversion
    case_mode: EnumProperty(
        name="Case",
        description="Case conversion mode",
        items=[
            ('NONE', "No Change", "Keep original case"),
            ('LOWER', "lowercase", "Convert to lowercase"),
            ('UPPER', "UPPERCASE", "Convert to uppercase"),
            ('TITLE', "Title Case", "Convert to title case"),
        ],
        default='NONE'
    )
    
    # Collection options
    collection_name: StringProperty(
        name="Collection Name",
        description="Name for new collection (blank = use active object name)",
        default=""
    )
    propagate_to_children: BoolProperty(
        name="Propagate to Objects",
        description="Apply collection name as prefix to child objects",
        default=False
    )


classes = (
    BATCHRENAME_PG_settings,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.batch_rename_settings = bpy.props.PointerProperty(
        type=BATCHRENAME_PG_settings
    )


def unregister():
    del bpy.types.Scene.batch_rename_settings
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
