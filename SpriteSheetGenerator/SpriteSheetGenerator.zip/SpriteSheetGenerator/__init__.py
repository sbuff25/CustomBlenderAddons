bl_info = {
    "name": "Sprite Sheet Generator",
    "author": "Spencer",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Sprite Sheet",
    "description": "Convert image sequences to sprite sheets",
    "category": "Import-Export",
}

import bpy
import os
import re
from bpy.props import (
    StringProperty,
    IntProperty,
    EnumProperty,
    BoolProperty,
    PointerProperty,
)
from bpy.types import PropertyGroup, Operator, Panel


def get_image_sequence(directory, pattern=""):
    """
    Scan directory for image files and return sorted list.
    Supports common image formats used in sequences.
    """
    supported_extensions = {'.png', '.jpg', '.jpeg', '.tga', '.bmp', '.tiff', '.tif', '.exr'}
    
    if not os.path.isdir(directory):
        return []
    
    images = []
    for filename in os.listdir(directory):
        name, ext = os.path.splitext(filename)
        if ext.lower() in supported_extensions:
            if not pattern or pattern.lower() in filename.lower():
                images.append(filename)
    
    # Natural sort to handle frame numbers correctly (frame1, frame2, ..., frame10, frame11)
    def natural_sort_key(s):
        return [int(text) if text.isdigit() else text.lower() 
                for text in re.split(r'(\d+)', s)]
    
    images.sort(key=natural_sort_key)
    return images


def calculate_grid_dimensions(num_images, columns=0, rows=0):
    """
    Calculate optimal grid dimensions for sprite sheet.
    If columns specified, calculate rows. If rows specified, calculate columns.
    If neither, find a near-square arrangement.
    """
    import math
    
    if num_images == 0:
        return 1, 1
    
    if columns > 0 and rows > 0:
        return columns, rows
    elif columns > 0:
        rows = math.ceil(num_images / columns)
        return columns, rows
    elif rows > 0:
        columns = math.ceil(num_images / rows)
        return columns, rows
    else:
        # Auto-calculate near-square grid
        columns = math.ceil(math.sqrt(num_images))
        rows = math.ceil(num_images / columns)
        return columns, rows


class SPRITESHEET_PG_properties(PropertyGroup):
    """Property group for sprite sheet settings."""
    
    source_directory: StringProperty(
        name="Source Directory",
        description="Directory containing the image sequence",
        subtype='DIR_PATH',
        default="",
    )
    
    filename_filter: StringProperty(
        name="Filename Filter",
        description="Optional filter to match specific files (e.g., 'walk' to match walk_001.png)",
        default="",
    )
    
    columns: IntProperty(
        name="Columns",
        description="Number of columns (0 = auto-calculate)",
        default=0,
        min=0,
        max=100,
    )
    
    rows: IntProperty(
        name="Rows",
        description="Number of rows (0 = auto-calculate)",
        default=0,
        min=0,
        max=100,
    )
    
    padding: IntProperty(
        name="Padding",
        description="Padding between sprites in pixels",
        default=0,
        min=0,
        max=100,
    )
    
    output_format: EnumProperty(
        name="Output Format",
        description="Output image format",
        items=[
            ('PNG', "PNG", "PNG format with transparency support"),
            ('JPEG', "JPEG", "JPEG format (no transparency)"),
            ('TARGA', "TGA", "Targa format"),
            ('BMP', "BMP", "Bitmap format"),
        ],
        default='PNG',
    )
    
    output_path: StringProperty(
        name="Output Path",
        description="Path to save the sprite sheet",
        subtype='FILE_PATH',
        default="//spritesheet.png",
    )
    
    scale_factor: IntProperty(
        name="Scale %",
        description="Scale factor for output (100 = original size)",
        default=100,
        min=10,
        max=400,
    )
    
    reverse_order: BoolProperty(
        name="Reverse Order",
        description="Reverse the order of images in the sequence",
        default=False,
    )


class SPRITESHEET_OT_scan_directory(Operator):
    """Scan the source directory and report found images"""
    bl_idname = "spritesheet.scan_directory"
    bl_label = "Scan Directory"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        props = context.scene.spritesheet_props
        
        directory = bpy.path.abspath(props.source_directory)
        if not directory or not os.path.isdir(directory):
            self.report({'ERROR'}, "Please select a valid directory")
            return {'CANCELLED'}
        
        images = get_image_sequence(directory, props.filename_filter)
        
        if not images:
            self.report({'WARNING'}, "No images found in directory")
        else:
            cols, rows = calculate_grid_dimensions(
                len(images), 
                props.columns, 
                props.rows
            )
            self.report({'INFO'}, f"Found {len(images)} images. Grid: {cols}x{rows}")
        
        return {'FINISHED'}


class SPRITESHEET_OT_generate(Operator):
    """Generate sprite sheet from image sequence"""
    bl_idname = "spritesheet.generate"
    bl_label = "Generate Sprite Sheet"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.spritesheet_props
        
        # Validate source directory
        directory = bpy.path.abspath(props.source_directory)
        if not directory or not os.path.isdir(directory):
            self.report({'ERROR'}, "Please select a valid source directory")
            return {'CANCELLED'}
        
        # Get image sequence
        images = get_image_sequence(directory, props.filename_filter)
        if not images:
            self.report({'ERROR'}, "No images found in directory")
            return {'CANCELLED'}
        
        if props.reverse_order:
            images.reverse()
        
        # Calculate grid dimensions
        num_images = len(images)
        columns, rows = calculate_grid_dimensions(num_images, props.columns, props.rows)
        
        # Load first image to get dimensions
        first_image_path = os.path.join(directory, images[0])
        first_img = bpy.data.images.load(first_image_path, check_existing=False)
        sprite_width = first_img.size[0]
        sprite_height = first_img.size[1]
        
        # Apply scale factor
        scale = props.scale_factor / 100.0
        scaled_sprite_width = int(sprite_width * scale)
        scaled_sprite_height = int(sprite_height * scale)
        
        # Calculate final dimensions
        padding = props.padding
        sheet_width = (scaled_sprite_width * columns) + (padding * (columns + 1))
        sheet_height = (scaled_sprite_height * rows) + (padding * (rows + 1))
        
        # Create output image
        sheet_name = "SpriteSheet_Output"
        if sheet_name in bpy.data.images:
            bpy.data.images.remove(bpy.data.images[sheet_name])
        
        sheet = bpy.data.images.new(
            name=sheet_name,
            width=sheet_width,
            height=sheet_height,
            alpha=True,
            float_buffer=False,
        )
        
        # Initialize with transparent pixels
        pixels = [0.0] * (sheet_width * sheet_height * 4)
        
        # Process each image
        for idx, filename in enumerate(images):
            if idx >= columns * rows:
                self.report({'WARNING'}, f"Grid too small, skipping {num_images - idx} images")
                break
            
            # Calculate grid position (top-left to bottom-right, row by row)
            col = idx % columns
            row = idx // columns
            
            # Load source image
            img_path = os.path.join(directory, filename)
            src_img = bpy.data.images.load(img_path, check_existing=False)
            
            # Get source pixels
            src_pixels = list(src_img.pixels[:])
            src_width = src_img.size[0]
            src_height = src_img.size[1]
            
            # Calculate position in sheet (Blender images are bottom-up)
            # We want top-left origin, so invert row
            inverted_row = rows - 1 - row
            x_offset = padding + (col * (scaled_sprite_width + padding))
            y_offset = padding + (inverted_row * (scaled_sprite_height + padding))
            
            # Copy pixels (with optional scaling via nearest neighbor)
            for y in range(scaled_sprite_height):
                for x in range(scaled_sprite_width):
                    # Source coordinates (handle scaling)
                    src_x = int(x / scale) if scale != 1.0 else x
                    src_y = int(y / scale) if scale != 1.0 else y
                    
                    if src_x >= src_width or src_y >= src_height:
                        continue
                    
                    # Source pixel index
                    src_idx = (src_y * src_width + src_x) * 4
                    
                    # Destination coordinates
                    dest_x = x_offset + x
                    dest_y = y_offset + y
                    dest_idx = (dest_y * sheet_width + dest_x) * 4
                    
                    # Copy RGBA
                    if src_idx + 3 < len(src_pixels) and dest_idx + 3 < len(pixels):
                        pixels[dest_idx] = src_pixels[src_idx]
                        pixels[dest_idx + 1] = src_pixels[src_idx + 1]
                        pixels[dest_idx + 2] = src_pixels[src_idx + 2]
                        pixels[dest_idx + 3] = src_pixels[src_idx + 3]
            
            # Clean up loaded source image
            bpy.data.images.remove(src_img)
        
        # Clean up first image reference
        bpy.data.images.remove(first_img)
        
        # Apply pixels to sheet
        sheet.pixels = pixels
        sheet.update()
        
        # Save the sprite sheet
        output_path = bpy.path.abspath(props.output_path)
        
        # Ensure output directory exists
        output_dir = os.path.dirname(output_path)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        # Set file format
        sheet.file_format = props.output_format
        
        # Save
        sheet.save_render(output_path)
        
        self.report({'INFO'}, 
            f"Sprite sheet saved: {output_path} ({sheet_width}x{sheet_height}, {columns}x{rows} grid)")
        
        return {'FINISHED'}


class SPRITESHEET_PT_main_panel(Panel):
    """Main panel for Sprite Sheet Generator"""
    bl_label = "Sprite Sheet Generator"
    bl_idname = "SPRITESHEET_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Sprite Sheet"
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.spritesheet_props
        
        # Source settings
        box = layout.box()
        box.label(text="Source", icon='FILE_FOLDER')
        box.prop(props, "source_directory")
        box.prop(props, "filename_filter")
        box.operator("spritesheet.scan_directory", icon='VIEWZOOM')
        
        # Grid settings
        box = layout.box()
        box.label(text="Grid Layout", icon='MESH_GRID')
        row = box.row(align=True)
        row.prop(props, "columns")
        row.prop(props, "rows")
        box.label(text="(0 = auto-calculate)", icon='INFO')
        box.prop(props, "padding")
        
        # Transform settings
        box = layout.box()
        box.label(text="Transform", icon='MODIFIER')
        box.prop(props, "scale_factor")
        box.prop(props, "reverse_order")
        
        # Output settings
        box = layout.box()
        box.label(text="Output", icon='EXPORT')
        box.prop(props, "output_format")
        box.prop(props, "output_path")
        
        # Generate button
        layout.separator()
        layout.operator("spritesheet.generate", icon='RENDER_RESULT', text="Generate Sprite Sheet")


classes = (
    SPRITESHEET_PG_properties,
    SPRITESHEET_OT_scan_directory,
    SPRITESHEET_OT_generate,
    SPRITESHEET_PT_main_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.spritesheet_props = PointerProperty(type=SPRITESHEET_PG_properties)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.spritesheet_props


if __name__ == "__main__":
    register()
